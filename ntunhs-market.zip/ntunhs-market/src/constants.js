// ─── 北護大學 正確科系列表 ───────────────────────────────────────
export const COLLEGES = [
  {
    name: '護理學院',
    depts: [
      '護理系（所）',
      '護理助產及婦女健康系（所）',
      '醫護教育暨數位學習系（所）',
      '高齡健康照護系（所）',
    ],
  },
  {
    name: '健康科技學院',
    depts: [
      '健康事業管理系（所）',
      '資訊管理系（所）',
      '長期照護系（所）',
      '休閒產業與健康促進系（所）',
      '語言治療與聽力學系（所）',
    ],
  },
  {
    name: '人類發展與健康學院',
    depts: [
      '嬰幼兒保育系（所）',
      '運動保健系（所）',
      '生死與健康心理諮商系（所）',
    ],
  },
];

// Flat list for simple use
export const ALL_DEPTS = COLLEGES.flatMap(c => c.depts);

export const PRODUCT_CATEGORIES = ['書籍', '彩妝', '衣服', '生活用品'];
export const JOB_TYPES          = ['校內工讀', '校外兼職', '實習機會'];
export const COURSE_TYPES       = ['必修課程', '選修課程'];
