import { useState } from 'react';
import { COLLEGES } from '../constants';

function DeptSelect({ value, onChange, required, style }) {
  return (
    <select value={value} onChange={onChange} required={required} style={style}>
      <option value="">請選擇科系</option>
      {COLLEGES.map(c => (
        <optgroup key={c.name} label={`── ${c.name} ──`}>
          {c.depts.map(d => <option key={d} value={d}>{d}</option>)}
        </optgroup>
      ))}
    </select>
  );
}

export function LoginPage({ setPage, setIsLoggedIn }) {
  const [form, setForm] = useState({ studentId: '', password: '' });
  const inp = { width: '100%', padding: '11px 14px', border: '1px solid #e2e8f0', borderRadius: 10, fontSize: 14, outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit' };

  return (
    <div style={{ minHeight: '70vh', background: 'linear-gradient(135deg,#f0f9ff,#e0f2fe)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px' }}>
      <div style={{ maxWidth: 420, width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ width: 72, height: 72, background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', borderRadius: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
            <span style={{ color: '#fff', fontSize: 32, fontWeight: 800 }}>北</span>
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: '#1e293b', marginBottom: 4 }}>北護小物販賣網站</h1>
          <p style={{ color: '#64748b', fontSize: 13 }}>臺北護理健康大學 限校內學生使用</p>
        </div>
        <div style={{ background: '#fff', borderRadius: 18, padding: '28px 24px', boxShadow: '0 4px 24px rgba(0,0,0,.09)' }}>
          <form onSubmit={e => { e.preventDefault(); setIsLoggedIn(true); setPage('home'); }}>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>學號 *</label>
              <input required value={form.studentId} onChange={e => setForm({ ...form, studentId: e.target.value })} placeholder="請輸入學號" style={inp} />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>密碼 *</label>
              <input required type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="請輸入密碼" style={inp} />
            </div>
            <button type="submit" style={{ width: '100%', background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', color: '#fff', border: 'none', padding: '13px 0', borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: 'pointer', marginBottom: 14, fontFamily: 'inherit' }}>
              登入
            </button>
            <p style={{ textAlign: 'center', fontSize: 13, color: '#64748b' }}>
              還沒有帳號？
              <button type="button" onClick={() => setPage('register')} style={{ border: 'none', background: 'none', color: '#0ea5e9', cursor: 'pointer', fontWeight: 600, fontFamily: 'inherit' }}>立即註冊</button>
            </p>
          </form>
        </div>
        <div style={{ marginTop: 14, background: '#dbeafe', borderRadius: 10, padding: '12px 16px', textAlign: 'center', fontSize: 12, color: '#1d4ed8', lineHeight: 1.8 }}>
          本平台僅限北護大學學生使用，請以學號登入
        </div>
      </div>
    </div>
  );
}

export function RegisterPage({ setPage, setIsLoggedIn }) {
  const [form, setForm] = useState({ name: '', studentId: '', dept: '', email: '', password: '', confirm: '' });
  const [err, setErr] = useState('');
  const inp = { width: '100%', padding: '10px 14px', border: '1px solid #e2e8f0', borderRadius: 10, fontSize: 14, outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit' };

  const submit = e => {
    e.preventDefault();
    if (form.password !== form.confirm) { setErr('密碼不一致！'); return; }
    setIsLoggedIn(true);
    setPage('home');
  };

  return (
    <div style={{ minHeight: '70vh', background: 'linear-gradient(135deg,#f0f9ff,#e0f2fe)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px' }}>
      <div style={{ maxWidth: 460, width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ width: 64, height: 64, background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
            <span style={{ color: '#fff', fontSize: 28, fontWeight: 800 }}>北</span>
          </div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#1e293b', marginBottom: 4 }}>建立新帳號</h1>
        </div>
        <div style={{ background: '#fff', borderRadius: 18, padding: '24px 22px', boxShadow: '0 4px 24px rgba(0,0,0,.09)' }}>
          <form onSubmit={submit}>
            <div style={{ marginBottom: 13 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>姓名 *</label>
              <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="請輸入姓名" style={inp} />
            </div>
            <div style={{ marginBottom: 13 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>學號 *</label>
              <input required value={form.studentId} onChange={e => setForm({ ...form, studentId: e.target.value })} placeholder="請輸入學號" style={inp} />
            </div>
            <div style={{ marginBottom: 13 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>科系 *</label>
              <DeptSelect value={form.dept} onChange={e => setForm({ ...form, dept: e.target.value })} required style={inp} />
            </div>
            <div style={{ marginBottom: 13 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>學校 Email *</label>
              <input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="xxxxx@ntunhs.edu.tw" style={inp} />
            </div>
            <div style={{ marginBottom: 13 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>密碼 *</label>
              <input required type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="請輸入密碼（至少 8 碼）" style={inp} />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>確認密碼 *</label>
              <input required type="password" value={form.confirm} onChange={e => setForm({ ...form, confirm: e.target.value })} placeholder="再輸入一次密碼" style={inp} />
            </div>
            {err && <p style={{ color: '#ef4444', fontSize: 13, marginBottom: 10 }}>{err}</p>}
            <label style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 18, cursor: 'pointer', fontSize: 13, color: '#475569' }}>
              <input type="checkbox" required style={{ marginTop: 2 }} />
              我同意使用條款與隱私政策，並確認為北護大學在學學生
            </label>
            <button type="submit" style={{ width: '100%', background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', color: '#fff', border: 'none', padding: '13px 0', borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: 'pointer', marginBottom: 12, fontFamily: 'inherit' }}>
              註冊
            </button>
            <p style={{ textAlign: 'center', fontSize: 13, color: '#64748b' }}>
              已有帳號？
              <button type="button" onClick={() => setPage('login')} style={{ border: 'none', background: 'none', color: '#0ea5e9', cursor: 'pointer', fontWeight: 600, fontFamily: 'inherit' }}>立即登入</button>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
