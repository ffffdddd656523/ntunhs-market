import { useState } from 'react';
import { Badge } from '../components/Common';
import { SearchIcon, UserIcon } from '../components/Icons';
import { COURSES } from '../data';

export default function CourseListPage() {
  const [search,setSearch]=useState('');
  const [type,setType]=useState('all');
  const filtered=COURSES.filter(c=>{
    if(type!=='all'&&c.type!==type) return false;
    if(search&&!c.title.includes(search)&&!c.courseName.includes(search)) return false;
    return true;
  });
  return (
    <div style={{maxWidth:1000,margin:'0 auto',padding:'32px 20px'}}>
      <h1 style={{fontSize:26,fontWeight:800,color:'#1e293b',marginBottom:6}}>換課資訊</h1>
      <p style={{color:'#64748b',marginBottom:24}}>課程時段交換需求</p>
      <div style={{display:'flex',gap:10,marginBottom:24,flexWrap:'wrap'}}>
        <div style={{position:'relative',flex:1,minWidth:180}}>
          <div style={{position:'absolute',left:11,top:'50%',transform:'translateY(-50%)',color:'#94a3b8'}}><SearchIcon/></div>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜尋課程..." style={{width:'100%',padding:'10px 10px 10px 38px',border:'1px solid #e2e8f0',borderRadius:10,fontSize:14,outline:'none',boxSizing:'border-box',fontFamily:'inherit'}}/>
        </div>
        {['all','必修課程','選修課程'].map(t=>(
          <button key={t} onClick={()=>setType(t)} style={{padding:'10px 14px',borderRadius:10,border:`1.5px solid ${type===t?'#22c55e':'#e2e8f0'}`,background:type===t?'#dcfce7':'#fff',color:type===t?'#16a34a':'#64748b',cursor:'pointer',fontWeight:600,fontSize:13,fontFamily:'inherit'}}>
            {t==='all'?'全部':t}
          </button>
        ))}
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:14}}>
        {filtered.map(c=>(
          <div key={c.id} style={{background:'#fff',borderRadius:16,padding:'20px 22px',boxShadow:'0 2px 10px rgba(0,0,0,.06)'}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
              <Badge color={c.type==='必修課程'?'#1d4ed8':'#7c3aed'} bg={c.type==='必修課程'?'#dbeafe':'#ede9fe'}>{c.type}</Badge>
              <Badge color="#15803d" bg="#dcfce7">{c.courseName}</Badge>
              <span style={{marginLeft:'auto',fontSize:12,color:'#94a3b8'}}>{c.date}</span>
            </div>
            <h3 style={{fontSize:16,fontWeight:700,color:'#1e293b',marginBottom:10}}>{c.title}</h3>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,background:'#f8fafc',borderRadius:10,padding:'12px 14px',marginBottom:10}}>
              <div><div style={{fontSize:11,color:'#94a3b8',marginBottom:2}}>現在時段</div><div style={{fontSize:13,fontWeight:600,color:'#1e293b'}}>{c.currentTime}</div></div>
              <div><div style={{fontSize:11,color:'#94a3b8',marginBottom:2}}>希望換到</div><div style={{fontSize:13,fontWeight:600,color:'#0284c7'}}>{c.desiredTime}</div></div>
            </div>
            <p style={{fontSize:13,color:'#64748b',marginBottom:10}}>原因：{c.reason}</p>
            <div style={{display:'flex',justifyContent:'space-between',flexWrap:'wrap',gap:6,fontSize:13}}>
              <span style={{display:'flex',gap:5,alignItems:'center',color:'#475569'}}><UserIcon/>{c.poster}（{c.department}）</span>
              <span style={{color:'#0284c7',fontWeight:600}}>聯絡：{c.contact}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
