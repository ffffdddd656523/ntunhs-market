import { useState } from 'react';
import { StarIcon, LayersIcon, CheckIcon, UsersIcon, ShoppingBagIcon, BriefcaseIcon, RefreshIcon, MessageCircleIcon, ImageIcon, UserIcon } from '../components/Icons';

/* ──────────── 報表資料 ──────────── */
const TEAM_MEMBERS = [
  { name: '組員 A', role: '前端開發 / 商品功能', dept: '資訊管理系（所）', contrib: '商品列表、商品詳情、以圖搜圖頁面、全域路由架構' },
  { name: '組員 B', role: '前端開發 / 會員系統', dept: '資訊管理系（所）', contrib: '登入、註冊、會員中心、圖片上傳 Modal' },
  { name: '組員 C', role: 'UI/UX 設計', dept: '資訊管理系（所）', contrib: '視覺設計、Navbar、Footer、首頁 Hero 區塊' },
  { name: '組員 D', role: '資料規劃 / 測試', dept: '資訊管理系（所）', contrib: '資料架構、打工與換課模組、聊天室功能' },
];

const FEATURES = [
  { icon: <ShoppingBagIcon />, color: '#0ea5e9', bg: '#e0f2fe', title: '商品二手販售', desc: '分書籍、彩妝、衣服、生活用品四大類，支援圖片、關鍵字與價格篩選，並可加入「典藏」收藏商品。' },
  { icon: <BriefcaseIcon />, color: '#f97316', bg: '#ffedd5', title: '打工資訊公告', desc: '區分校內工讀、校外兼職、實習機會三種類型，顯示地點、薪資、時段與聯絡方式。' },
  { icon: <RefreshIcon />, color: '#22c55e', bg: '#dcfce7', title: '換課資訊交流', desc: '學生可公告需要換課的科目、現在時段與希望換到的時段，並直接留下聯絡方式。' },
  { icon: <MessageCircleIcon />, color: '#8b5cf6', bg: '#ede9fe', title: '私人聊天室', desc: '商品頁點「聯絡賣家」可進入一對一聊天室，支援即時傳送訊息與未讀數提示。' },
  { icon: <UsersIcon />, color: '#ec4899', bg: '#fce7f3', title: '北護大群聊天室', desc: '全校學生可在公開大群中互相交流，發布各種資訊，訊息即時更新。' },
  { icon: <ImageIcon />, color: '#f59e0b', bg: '#fef3c7', title: '以圖搜圖', desc: '學生可上傳圖片搜尋相似商品，並透過圖片上傳 Modal 支援旋轉、縮放後確認使用。' },
  { icon: <UserIcon />, color: '#14b8a6', bg: '#ccfbf1', title: '會員系統', desc: '提供登入 / 註冊流程，會員中心可管理「我的貼文」與「典藏商品」兩個分頁。' },
  { icon: <LayersIcon />, color: '#6366f1', bg: '#e0e7ff', title: '模組化架構', desc: '使用 React 18 組件化開發，程式碼分 pages / components 兩層，易於團隊分工擴充。' },
];

const TECH_STACK = [
  { name: 'React 18', desc: '前端框架，使用 Hooks 管理狀態', color: '#0ea5e9' },
  { name: 'Create React App', desc: '零配置建構工具，一鍵啟動與打包', color: '#22c55e' },
  { name: 'Inline Styles', desc: '全元件自帶樣式，無外部 CSS 依賴', color: '#f97316' },
  { name: 'FileReader API', desc: '瀏覽器原生圖片讀取，無需後端', color: '#8b5cf6' },
  { name: 'Canvas API', desc: '圖片旋轉 / 縮放後轉為 DataURL', color: '#ec4899' },
  { name: 'Unsplash CDN', desc: '示範商品圖片來源', color: '#64748b' },
];

const DEMO_STEPS = [
  { step: '01', title: '開啟首頁，展示 Hero 搜尋列', detail: '說明網站定位：專為北護大學生設計的二手交易與資訊平台。點擊「開始瀏覽」進入商品列表。' },
  { step: '02', title: '商品分類頁 — 篩選功能', detail: '展示左側篩選欄：類別切換（書籍 / 彩妝 / 衣服 / 生活用品）、關鍵字搜尋、價格區間、排序。強調 UI 回應速度快。' },
  { step: '03', title: '點擊商品卡片進入商品詳情', detail: '說明商品詳情頁顯示：大圖、價格、賣家資訊（科系已更新為北護正確科系）、交易安全提醒。' },
  { step: '04', title: '以圖搜圖功能', detail: '點選導覽列「商品分類」→ 首頁的「以圖搜圖」按鈕，示範上傳圖片、旋轉縮放、確認後搜尋結果。' },
  { step: '05', title: '登入 / 註冊流程', detail: '輸入任意學號與密碼即可登入（Demo 版本）。展示科系下拉選單已整合三個學院共 12 個科系所。' },
  { step: '06', title: '發布貼文 — 三種類型', detail: '登入後進入「發布貼文」，示範三種類型切換（商品、打工、換課），以及圖片上傳 Modal 的旋轉、縮放功能。' },
  { step: '07', title: '私人聊天室', detail: '點選任一商品「聯絡賣家」，展示私人聊天室：左側聯絡人列表含未讀數，右側即時傳送訊息泡泡。' },
  { step: '08', title: '北護大群聊天室', detail: '導覽列「北護大群」，展示公開多人聊天室，輸入任意訊息即可送出，說明未來可串接 WebSocket 實現真正即時。' },
  { step: '09', title: '會員中心 — 我的貼文與典藏', detail: '點「會員中心」，展示「我的貼文」管理（含上架中 / 已售出 / 已下架狀態）與「典藏商品」收藏列表。' },
  { step: '10', title: '打工與換課資訊', detail: '分別進入「打工資訊」與「換課資訊」頁面，展示類別切換篩選與詳細資訊卡。' },
];

const FUTURE = [
  '串接 Firebase / Supabase 實現真實帳號驗證與資料庫',
  '整合 WebSocket 讓聊天室達到真正即時',
  '學生證 OCR 驗證確保僅限北護學生使用',
  '商品圖片上傳至 Firebase Storage 雲端儲存',
  '加入評價系統與交易紀錄功能',
  'PWA 支援，讓網站可安裝到手機主畫面',
];

/* ──────────── 元件 ──────────── */
function Section({ title, icon, children }) {
  return (
    <section style={{ background: '#fff', borderRadius: 18, padding: '28px 28px 24px', boxShadow: '0 2px 12px rgba(0,0,0,.06)', marginBottom: 24 }}>
      <h2 style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 19, fontWeight: 800, color: '#1e293b', marginBottom: 20 }}>
        <span style={{ color: '#0ea5e9' }}>{icon}</span>{title}
      </h2>
      {children}
    </section>
  );
}

export default function PresentationPage() {
  const [activeStep, setActiveStep] = useState(null);
  const [printMode, setPrintMode] = useState(false);

  return (
    <div style={{ maxWidth: 960, margin: '0 auto', padding: '32px 20px' }}>

      {/* Title Banner */}
      <div style={{ background: 'linear-gradient(135deg,#0284c7,#075985)', borderRadius: 20, padding: '36px 32px', marginBottom: 28, color: '#fff', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -40, right: -40, width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,.06)' }} />
        <div style={{ position: 'absolute', bottom: -60, left: -20, width: 220, height: 220, borderRadius: '50%', background: 'rgba(255,255,255,.04)' }} />
        <div style={{ position: 'relative' }}>
          <div style={{ fontSize: 12, color: '#7dd3fc', fontWeight: 600, marginBottom: 8, letterSpacing: 2 }}>NTUNHS MARKET — 專題成果</div>
          <h1 style={{ fontSize: 'clamp(22px,4vw,34px)', fontWeight: 800, marginBottom: 10 }}>北護小物販賣網站</h1>
          <p style={{ color: '#bae6fd', fontSize: 15, lineHeight: 1.7, maxWidth: 600 }}>
            臺北護理健康大學學生二手交易與資訊交流平台<br/>
            整合商品販售、打工資訊、換課資訊、聊天室與會員系統
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 20, flexWrap: 'wrap' }}>
            {['React 18', 'CRA', 'Inline Styles', 'FileReader API'].map(t => (
              <span key={t} style={{ background: 'rgba(255,255,255,.15)', border: '1px solid rgba(255,255,255,.25)', borderRadius: 20, padding: '4px 12px', fontSize: 12, fontWeight: 600 }}>{t}</span>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
        <button
          onClick={() => window.print()}
          style={{ background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', color: '#fff', border: 'none', padding: '10px 20px', borderRadius: 10, cursor: 'pointer', fontWeight: 700, fontSize: 14, fontFamily: 'inherit' }}
        >
          🖨️ 列印此報表
        </button>
        <button
          onClick={() => { const el = document.getElementById('report-content'); const w = window.open(''); w.document.write('<html><head><title>北護市集成果報表</title></head><body>' + el.innerHTML + '</body></html>'); w.document.close(); w.print(); }}
          style={{ background: '#f8fafc', color: '#475569', border: '1px solid #e2e8f0', padding: '10px 20px', borderRadius: 10, cursor: 'pointer', fontWeight: 600, fontSize: 14, fontFamily: 'inherit' }}
        >
          📄 匯出報告內容
        </button>
      </div>

      <div id="report-content">

        {/* 功能清單 */}
        <Section title="功能模組總覽" icon={<LayersIcon />}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: 14 }}>
            {FEATURES.map(f => (
              <div key={f.title} style={{ display: 'flex', gap: 14, alignItems: 'flex-start', background: '#f8fafc', borderRadius: 12, padding: '14px 16px' }}>
                <div style={{ width: 40, height: 40, borderRadius: '50%', background: f.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: f.color }}>
                  {f.icon}
                </div>
                <div>
                  <div style={{ fontWeight: 700, color: '#1e293b', fontSize: 14, marginBottom: 4 }}>{f.title}</div>
                  <div style={{ fontSize: 12, color: '#64748b', lineHeight: 1.6 }}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* 評審展示步驟 */}
        <Section title="評審展示流程（建議順序）" icon={<StarIcon />}>
          <p style={{ fontSize: 13, color: '#64748b', marginBottom: 18 }}>
            💡 每個步驟點擊可展開詳細說明。建議展示時間約 10–15 分鐘。
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {DEMO_STEPS.map((s, i) => (
              <div key={i}
                onClick={() => setActiveStep(activeStep === i ? null : i)}
                style={{ background: activeStep === i ? '#f0f9ff' : '#f8fafc', borderRadius: 12, padding: '14px 18px', cursor: 'pointer', border: `1.5px solid ${activeStep === i ? '#0ea5e9' : '#e2e8f0'}`, transition: 'all .15s' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ width: 32, height: 32, background: activeStep === i ? '#0ea5e9' : '#e2e8f0', color: activeStep === i ? '#fff' : '#64748b', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>
                    {s.step}
                  </span>
                  <span style={{ fontWeight: 700, color: '#1e293b', fontSize: 14, flex: 1 }}>{s.title}</span>
                  <span style={{ fontSize: 18, color: '#94a3b8' }}>{activeStep === i ? '▲' : '▼'}</span>
                </div>
                {activeStep === i && (
                  <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #bae6fd', fontSize: 13, color: '#475569', lineHeight: 1.8, paddingLeft: 44 }}>
                    {s.detail}
                  </div>
                )}
              </div>
            ))}
          </div>
        </Section>

        {/* 技術棧 */}
        <Section title="技術棧" icon={<LayersIcon />}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(240px,1fr))', gap: 12 }}>
            {TECH_STACK.map(t => (
              <div key={t.name} style={{ background: '#f8fafc', borderRadius: 10, padding: '12px 16px', display: 'flex', gap: 12, alignItems: 'center' }}>
                <span style={{ width: 10, height: 10, borderRadius: '50%', background: t.color, flexShrink: 0 }} />
                <div>
                  <div style={{ fontWeight: 700, color: '#1e293b', fontSize: 14 }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: '#64748b' }}>{t.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* 組員分工 */}
        <Section title="組員分工" icon={<UsersIcon />}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(340px,1fr))', gap: 14 }}>
            {TEAM_MEMBERS.map((m, i) => {
              const colors = ['#0ea5e9','#22c55e','#f97316','#8b5cf6'];
              return (
                <div key={i} style={{ background: '#f8fafc', borderRadius: 12, padding: '16px 18px', display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                  <div style={{ width: 42, height: 42, borderRadius: '50%', background: colors[i % colors.length], display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 16, flexShrink: 0 }}>
                    {m.name[2]}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: '#1e293b' }}>{m.name}</div>
                    <div style={{ fontSize: 12, color: colors[i % colors.length], fontWeight: 600, marginBottom: 4 }}>{m.role}</div>
                    <div style={{ fontSize: 12, color: '#64748b', marginBottom: 6 }}>{m.dept}</div>
                    <div style={{ fontSize: 12, color: '#475569', lineHeight: 1.6, background: '#fff', borderRadius: 8, padding: '6px 10px' }}>{m.contrib}</div>
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop: 14, background: '#fffbeb', borderRadius: 10, padding: '12px 16px', fontSize: 13, color: '#92400e' }}>
            ⚠️ 以上組員姓名、科系與分工為範本，請依照實際情況修改 <code style={{ background: '#fef3c7', padding: '1px 5px', borderRadius: 4 }}>src/pages/PresentationPage.jsx</code> 頂端的 <code style={{ background: '#fef3c7', padding: '1px 5px', borderRadius: 4 }}>TEAM_MEMBERS</code> 陣列。
          </div>
        </Section>

        {/* 未來規劃 */}
        <Section title="未來規劃" icon={<StarIcon />}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {FUTURE.map((f, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, background: '#f8fafc', borderRadius: 10, padding: '12px 16px' }}>
                <span style={{ width: 22, height: 22, background: '#dcfce7', color: '#16a34a', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 13 }}>
                  <CheckIcon />
                </span>
                <span style={{ fontSize: 14, color: '#374151', lineHeight: 1.6 }}>{f}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* Summary */}
        <div style={{ background: 'linear-gradient(135deg,#0f172a,#1e3a5f)', borderRadius: 18, padding: '28px 32px', color: '#fff', textAlign: 'center' }}>
          <h3 style={{ fontSize: 20, fontWeight: 800, marginBottom: 10 }}>專題總結</h3>
          <p style={{ color: '#bae6fd', fontSize: 14, lineHeight: 1.9, maxWidth: 640, margin: '0 auto' }}>
            北護小物販賣網站以 React 18 單頁應用實現了完整的校園二手交易平台，
            涵蓋商品、打工、換課三大資訊模組，以及即時聊天、會員系統與圖片上傳功能。
            整體架構清晰、組件分工明確，具備擴充為全端應用的基礎。
          </p>
        </div>

      </div>
    </div>
  );
}
