import { useState, useEffect, useRef } from 'react';
import { Avatar } from '../components/Common';
import { SearchIcon, SendIcon } from '../components/Icons';
import { CHATS_INIT } from '../data';

export default function ChatPage() {
  const [chats,setChats]=useState(CHATS_INIT);
  const [selected,setSelected]=useState('1');
  const [msg,setMsg]=useState('');
  const endRef=useRef(null);
  const cur=chats.find(c=>c.id===selected);
  const send=e=>{
    e.preventDefault();
    if(!msg.trim()) return;
    const m={id:'m'+Date.now(),sender:'me',text:msg,time:new Date().toLocaleTimeString('zh-TW',{hour:'2-digit',minute:'2-digit'})};
    setChats(cs=>cs.map(c=>c.id===selected?{...c,messages:[...c.messages,m],lastMessage:msg,unread:0}:c));
    setMsg('');
  };
  useEffect(()=>{if(endRef.current)endRef.current.scrollIntoView({behavior:'smooth'});},[cur&&cur.messages&&cur.messages.length]);
  return (
    <div style={{maxWidth:1100,margin:'0 auto',padding:'32px 20px'}}>
      <h1 style={{fontSize:26,fontWeight:800,color:'#1e293b',marginBottom:6}}>私人聊天室</h1>
      <p style={{color:'#64748b',marginBottom:18}}>與賣家一對一私訊</p>
      <div style={{background:'#fff',borderRadius:18,boxShadow:'0 2px 14px rgba(0,0,0,.07)',overflow:'hidden',display:'grid',gridTemplateColumns:'270px 1fr',height:520}}>
        <div style={{borderRight:'1px solid #f1f5f9',display:'flex',flexDirection:'column'}}>
          <div style={{padding:'12px 14px',borderBottom:'1px solid #f1f5f9'}}>
            <div style={{position:'relative'}}>
              <div style={{position:'absolute',left:9,top:'50%',transform:'translateY(-50%)',color:'#94a3b8'}}><SearchIcon/></div>
              <input placeholder="搜尋聊天室..." style={{width:'100%',padding:'8px 8px 8px 34px',border:'1px solid #e2e8f0',borderRadius:8,fontSize:12,outline:'none',boxSizing:'border-box',fontFamily:'inherit'}}/>
            </div>
          </div>
          <div style={{overflowY:'auto',flex:1}}>
            {chats.map(c=>(
              <button key={c.id} onClick={()=>{setSelected(c.id);setChats(cs=>cs.map(x=>x.id===c.id?{...x,unread:0}:x));}}
                style={{width:'100%',padding:'12px 14px',border:'none',background:selected===c.id?'#f0f9ff':'#fff',cursor:'pointer',textAlign:'left',borderBottom:'1px solid #f8fafc',display:'flex',gap:10,alignItems:'center',fontFamily:'inherit'}}>
                <Avatar name={c.name} color={c.color} size={40}/>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:2}}>
                    <span style={{fontWeight:600,fontSize:13,color:'#1e293b'}}>{c.name}</span>
                    <span style={{fontSize:10,color:'#94a3b8'}}>{c.time}</span>
                  </div>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <p style={{fontSize:12,color:'#64748b',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',maxWidth:110}}>{c.lastMessage}</p>
                    {c.unread>0&&<span style={{minWidth:16,height:16,background:'#ef4444',color:'#fff',borderRadius:99,fontSize:10,display:'flex',alignItems:'center',justifyContent:'center',padding:'0 4px'}}>{c.unread}</span>}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
        <div style={{display:'flex',flexDirection:'column'}}>
          <div style={{padding:'12px 18px',borderBottom:'1px solid #f1f5f9',display:'flex',alignItems:'center',gap:10}}>
            <Avatar name={cur&&cur.name} color={cur&&cur.color} size={36}/>
            <div><div style={{fontWeight:600,color:'#1e293b',fontSize:14}}>{cur&&cur.name}</div><div style={{fontSize:11,color:'#22c55e'}}>● 線上</div></div>
          </div>
          <div style={{flex:1,overflowY:'auto',padding:'16px',display:'flex',flexDirection:'column',gap:10}}>
            {cur&&cur.messages.map(m=>(
              <div key={m.id} style={{display:'flex',justifyContent:m.sender==='me'?'flex-end':'flex-start'}}>
                <div style={{maxWidth:'65%'}}>
                  <div style={{padding:'10px 13px',borderRadius:m.sender==='me'?'16px 16px 4px 16px':'16px 16px 16px 4px',background:m.sender==='me'?'linear-gradient(135deg,#0ea5e9,#0284c7)':'#f1f5f9',color:m.sender==='me'?'#fff':'#1e293b',fontSize:13,lineHeight:1.5}}>{m.text}</div>
                  <div style={{fontSize:10,color:'#94a3b8',marginTop:3,textAlign:m.sender==='me'?'right':'left'}}>{m.time}</div>
                </div>
              </div>
            ))}
            <div ref={endRef}/>
          </div>
          <form onSubmit={send} style={{padding:'12px 16px',borderTop:'1px solid #f1f5f9',display:'flex',gap:8}}>
            <input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="輸入訊息..." style={{flex:1,padding:'10px 12px',border:'1px solid #e2e8f0',borderRadius:10,fontSize:13,outline:'none',fontFamily:'inherit'}}/>
            <button type="submit" style={{background:'linear-gradient(135deg,#0ea5e9,#0284c7)',color:'#fff',border:'none',padding:'0 18px',borderRadius:10,cursor:'pointer',display:'flex',alignItems:'center',gap:5,fontWeight:600,fontFamily:'inherit',fontSize:13}}><SendIcon/>傳送</button>
          </form>
        </div>
      </div>
    </div>
  );
}
