import { useState } from 'react';
import { ProductCard } from '../components/Common';
import { ImageIcon, XIcon } from '../components/Icons';
import ImageUploadModal from '../components/ImageUploadModal';

export default function VisualSearchPage({ products, favorites, toggleFav, showProduct }) {
  const [uploadedImage,setUploadedImage]=useState(null);
  const [searching,setSearching]=useState(false);
  const [results,setResults]=useState(null);
  const [modalOpen,setModalOpen]=useState(false);

  const doSearch=()=>{
    setSearching(true);
    setTimeout(()=>{setSearching(false);setResults(products.slice(0,3));},1500);
  };

  return (
    <>
      <ImageUploadModal
        isOpen={modalOpen}
        onClose={()=>setModalOpen(false)}
        onConfirm={url=>{setUploadedImage(url);setResults(null);}}
        title="上傳搜尋圖片"
        aspect="自由比例"
      />
      <div style={{maxWidth:900,margin:'0 auto',padding:'32px 20px'}}>
        <div style={{textAlign:'center',marginBottom:28}}>
          <h1 style={{fontSize:26,fontWeight:800,color:'#1e293b',marginBottom:6}}>以圖搜圖</h1>
          <p style={{color:'#64748b'}}>上傳圖片，快速找到相似商品</p>
        </div>
        <div style={{background:'#fff',borderRadius:18,padding:28,boxShadow:'0 2px 14px rgba(0,0,0,.07)',marginBottom:24}}>
          {!uploadedImage ? (
            <button onClick={()=>setModalOpen(true)} style={{width:'100%',border:'2px dashed #e2e8f0',borderRadius:14,padding:'48px 20px',background:'#fafafa',cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',gap:10,fontFamily:'inherit',transition:'border-color .15s'}}
              onMouseEnter={e=>e.currentTarget.style.borderColor='#0ea5e9'} onMouseLeave={e=>e.currentTarget.style.borderColor='#e2e8f0'}>
              <div style={{color:'#94a3b8',width:48,height:48}}><ImageIcon/></div>
              <p style={{color:'#1e293b',fontWeight:600,fontSize:15}}>點擊開啟圖片上傳視窗</p>
              <p style={{color:'#94a3b8',fontSize:12}}>支援旋轉、縮放調整後搜尋</p>
            </button>
          ) : (
            <div style={{textAlign:'center'}}>
              <div style={{position:'relative',display:'inline-block',marginBottom:18}}>
                <img src={uploadedImage} alt="search" style={{maxHeight:260,borderRadius:12,objectFit:'cover'}}/>
                <button onClick={()=>{setUploadedImage(null);setResults(null);}} style={{position:'absolute',top:8,right:8,width:28,height:28,borderRadius:'50%',background:'#ef4444',border:'none',color:'#fff',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><XIcon/></button>
              </div>
              <div style={{display:'flex',gap:10,justifyContent:'center'}}>
                <button onClick={()=>setModalOpen(true)} style={{background:'#f1f5f9',color:'#475569',border:'none',padding:'10px 20px',borderRadius:10,cursor:'pointer',fontWeight:600,fontFamily:'inherit'}}>更換圖片</button>
                <button onClick={doSearch} disabled={searching} style={{background:'linear-gradient(135deg,#0ea5e9,#0284c7)',color:'#fff',border:'none',padding:'10px 28px',borderRadius:10,fontWeight:700,cursor:searching?'wait':'pointer',fontSize:14,fontFamily:'inherit'}}>
                  {searching?'搜尋中...':'開始搜尋'}
                </button>
              </div>
            </div>
          )}
        </div>
        {results&&(
          <div>
            <h2 style={{fontSize:17,fontWeight:700,color:'#1e293b',marginBottom:14}}>搜尋結果（{results.length} 件相似商品）</h2>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(230px,1fr))',gap:16}}>
              {results.map(p=><ProductCard key={p.id} product={p} onClick={showProduct} onFavorite={toggleFav} isFav={favorites.has(p.id)}/>)}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
