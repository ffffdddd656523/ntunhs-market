import { useState } from 'react';
import { ProductCard } from '../components/Common';
import { SearchIcon, FilterIcon } from '../components/Icons';

export default function ProductListPage({ products, favorites, toggleFav, showProduct }) {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('all');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [sort, setSort] = useState('latest');
  let filtered = products.filter(p=>{
    if(cat!=='all'&&p.category!==cat) return false;
    if(search&&!p.title.includes(search)&&!p.description.includes(search)) return false;
    if(priceMin&&p.price<+priceMin) return false;
    if(priceMax&&p.price>+priceMax) return false;
    return true;
  });
  if(sort==='price-low') filtered=[...filtered].sort((a,b)=>a.price-b.price);
  if(sort==='price-high') filtered=[...filtered].sort((a,b)=>b.price-a.price);
  const inp={width:'100%',padding:'8px 12px',border:'1px solid #e2e8f0',borderRadius:8,fontSize:13,outline:'none',fontFamily:'inherit'};
  return (
    <div style={{maxWidth:1200,margin:'0 auto',padding:'32px 20px'}}>
      <h1 style={{fontSize:26,fontWeight:800,color:'#1e293b',marginBottom:6}}>商品分類</h1>
      <p style={{color:'#64748b',marginBottom:28}}>瀏覽二手書、彩妝、衣服與生活用品</p>
      <div style={{display:'flex',flexWrap:'wrap',gap:24,alignItems:'flex-start'}}>
        <aside style={{width:220,flexShrink:0,background:'#fff',borderRadius:16,padding:'22px 18px',boxShadow:'0 2px 12px rgba(0,0,0,.06)',position:'sticky',top:80}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:18,color:'#1e293b',fontWeight:700,fontSize:14}}><FilterIcon/>篩選條件</div>
          <label style={{fontSize:12,color:'#475569',display:'block',marginBottom:5}}>關鍵字</label>
          <div style={{position:'relative',marginBottom:16}}>
            <div style={{position:'absolute',left:9,top:'50%',transform:'translateY(-50%)',color:'#94a3b8'}}><SearchIcon/></div>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜尋..." style={{...inp,padding:'8px 8px 8px 34px',boxSizing:'border-box'}}/>
          </div>
          <label style={{fontSize:12,color:'#475569',display:'block',marginBottom:5}}>類別</label>
          <select value={cat} onChange={e=>setCat(e.target.value)} style={{...inp,marginBottom:16}}>
            <option value="all">全部商品</option>
            {['書籍','彩妝','衣服','生活用品'].map(o=><option key={o} value={o}>{o}</option>)}
          </select>
          <label style={{fontSize:12,color:'#475569',display:'block',marginBottom:5}}>價格區間</label>
          <div style={{display:'flex',gap:6,marginBottom:16}}>
            <input type="number" placeholder="最低" value={priceMin} onChange={e=>setPriceMin(e.target.value)} style={{width:'50%',padding:'8px',border:'1px solid #e2e8f0',borderRadius:8,fontSize:12,outline:'none'}}/>
            <input type="number" placeholder="最高" value={priceMax} onChange={e=>setPriceMax(e.target.value)} style={{width:'50%',padding:'8px',border:'1px solid #e2e8f0',borderRadius:8,fontSize:12,outline:'none'}}/>
          </div>
          <label style={{fontSize:12,color:'#475569',display:'block',marginBottom:5}}>排序</label>
          <select value={sort} onChange={e=>setSort(e.target.value)} style={inp}>
            <option value="latest">最新</option>
            <option value="price-low">價格低到高</option>
            <option value="price-high">價格高到低</option>
          </select>
        </aside>
        <main style={{flex:1,minWidth:0}}>
          <p style={{color:'#64748b',fontSize:13,marginBottom:14}}>找到 <strong>{filtered.length}</strong> 個結果</p>
          {filtered.length===0
            ? <div style={{textAlign:'center',padding:'60px 0',color:'#94a3b8'}}><div style={{fontSize:40,marginBottom:10}}>🔍</div><p>找不到符合條件的商品</p></div>
            : <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(230px,1fr))',gap:16}}>
                {filtered.map(p=><ProductCard key={p.id} product={p} onClick={showProduct} onFavorite={toggleFav} isFav={favorites.has(p.id)}/>)}
              </div>
          }
        </main>
      </div>
    </div>
  );
}
