import { useState } from 'react';
import { CategoryBadge } from '../components/Common';
import { MailIcon, EditIcon, Trash2Icon, CameraIcon, UserIcon } from '../components/Icons';
import ImageUploadModal from '../components/ImageUploadModal';
import { COLLEGES } from '../constants';

export default function ProfilePage({ setIsLoggedIn, setPage, favorites, products }) {
  const [tab, setTab] = useState('posts');
  const [avatarModal, setAvatarModal] = useState(false);
  const [avatarImg, setAvatarImg] = useState(null);
  const [user, setUser] = useState({
    name: '王小明',
    studentId: '11012345',
    email: 'student001@ntunhs.edu.tw',
    department: '護理系（所）',
  });
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ ...user });

  const myPosts = [
    { id: '1', title: '護理學原理 第八版', category: '書籍', price: 350, status: 'active', date: '2天前', views: 48 },
    { id: '2', title: '解剖學講義', category: '書籍', price: 250, status: 'sold', date: '1週前', views: 35 },
    { id: '3', title: '實習用白色襯衫', category: '衣服', price: 200, status: 'inactive', date: '2週前', views: 22 },
  ];

  const statusMap = {
    active: { label: '上架中', color: '#16a34a', bg: '#dcfce7' },
    sold: { label: '已售出', color: '#374151', bg: '#f3f4f6' },
    inactive: { label: '已下架', color: '#dc2626', bg: '#fee2e2' },
  };

  const favProducts = products.filter(p => favorites.has(p.id));
  const inp = { width: '100%', padding: '9px 12px', border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit' };

  return (
    <>
      <ImageUploadModal
        isOpen={avatarModal}
        onClose={() => setAvatarModal(false)}
        onConfirm={url => setAvatarImg(url)}
        title="更換大頭照"
        aspect="1/1"
      />

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '32px 20px' }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: '#1e293b', marginBottom: 6 }}>會員中心</h1>
        <p style={{ color: '#64748b', marginBottom: 28 }}>管理個人資料與貼文</p>

        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 24, alignItems: 'start' }}>

          {/* Profile Card */}
          <div style={{ background: '#fff', borderRadius: 18, padding: '28px 22px', boxShadow: '0 2px 12px rgba(0,0,0,.07)', position: 'sticky', top: 80 }}>
            {/* Avatar */}
            <div style={{ textAlign: 'center', marginBottom: 20 }}>
              <div style={{ position: 'relative', width: 80, height: 80, margin: '0 auto 12px' }}>
                {avatarImg
                  ? <img src={avatarImg} alt="avatar" style={{ width: 80, height: 80, borderRadius: '50%', objectFit: 'cover', border: '3px solid #e0f2fe' }} />
                  : <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <span style={{ color: '#fff', fontSize: 30, fontWeight: 800 }}>{user.name[0]}</span>
                    </div>
                }
                <button
                  onClick={() => setAvatarModal(true)}
                  style={{ position: 'absolute', bottom: 0, right: 0, width: 26, height: 26, borderRadius: '50%', background: '#0ea5e9', border: '2px solid #fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}
                  title="更換大頭照"
                >
                  <CameraIcon />
                </button>
              </div>
              {!editing ? (
                <>
                  <h2 style={{ fontSize: 17, fontWeight: 700, color: '#1e293b', marginBottom: 2 }}>{user.name}</h2>
                  <p style={{ fontSize: 13, color: '#64748b', marginBottom: 10 }}>{user.department}</p>
                  <button onClick={() => { setEditForm({ ...user }); setEditing(true); }}
                    style={{ background: '#e0f2fe', color: '#0284c7', border: 'none', borderRadius: 8, padding: '6px 16px', cursor: 'pointer', fontWeight: 600, fontSize: 13, fontFamily: 'inherit', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                    <EditIcon />編輯資料
                  </button>
                </>
              ) : (
                <div style={{ textAlign: 'left' }}>
                  <div style={{ marginBottom: 10 }}>
                    <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>姓名</label>
                    <input value={editForm.name} onChange={e=>setEditForm({...editForm,name:e.target.value})} style={inp}/>
                  </div>
                  <div style={{ marginBottom: 10 }}>
                    <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>科系</label>
                    <select value={editForm.department} onChange={e=>setEditForm({...editForm,department:e.target.value})} style={inp}>
                      <option value="">請選擇科系</option>
                      {COLLEGES.map(c=>(
                        <optgroup key={c.name} label={`── ${c.name} ──`}>
                          {c.depts.map(d=><option key={d} value={d}>{d}</option>)}
                        </optgroup>
                      ))}
                    </select>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={()=>{setUser({...editForm});setEditing(false);}}
                      style={{ flex:1, background:'linear-gradient(135deg,#0ea5e9,#0284c7)', color:'#fff', border:'none', borderRadius:8, padding:'8px 0', cursor:'pointer', fontWeight:700, fontSize:13, fontFamily:'inherit' }}>儲存</button>
                    <button onClick={()=>setEditing(false)}
                      style={{ flex:1, background:'#f1f5f9', color:'#475569', border:'none', borderRadius:8, padding:'8px 0', cursor:'pointer', fontWeight:600, fontSize:13, fontFamily:'inherit' }}>取消</button>
                  </div>
                </div>
              )}
            </div>

            <div style={{ borderTop: '1px solid #f1f5f9', paddingTop: 16, fontSize: 13, color: '#475569', display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><UserIcon />{user.studentId}</div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><MailIcon />{user.email}</div>
            </div>

            <button onClick={() => { setIsLoggedIn(false); setPage('home'); }}
              style={{ width: '100%', marginTop: 20, background: '#fee2e2', color: '#dc2626', border: 'none', padding: '11px 0', borderRadius: 10, cursor: 'pointer', fontWeight: 600, fontSize: 14, fontFamily: 'inherit' }}>
              登出
            </button>
          </div>

          {/* Content Tabs */}
          <div>
            <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: '#f8fafc', borderRadius: 12, padding: 4 }}>
              {[['posts','我的貼文'],['favorites','典藏商品']].map(([v,l])=>(
                <button key={v} onClick={()=>setTab(v)}
                  style={{ flex:1, padding:'10px 0', border:'none', borderRadius:10, background:tab===v?'#fff':'transparent', color:tab===v?'#0ea5e9':'#64748b', fontWeight:700, cursor:'pointer', fontSize:14, boxShadow:tab===v?'0 2px 8px rgba(0,0,0,.06)':undefined, fontFamily:'inherit' }}>
                  {l}
                </button>
              ))}
            </div>

            {tab === 'posts' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {myPosts.map(p => {
                  const s = statusMap[p.status];
                  return (
                    <div key={p.id} style={{ background: '#fff', borderRadius: 14, padding: '18px 20px', boxShadow: '0 2px 10px rgba(0,0,0,.05)', display: 'flex', alignItems: 'center', gap: 16 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                          <CategoryBadge cat={p.category} />
                          <span style={{ padding: '2px 8px', borderRadius: 99, background: s.bg, color: s.color, fontSize: 12, fontWeight: 600 }}>{s.label}</span>
                        </div>
                        <h3 style={{ fontSize: 15, fontWeight: 700, color: '#1e293b', marginBottom: 4 }}>{p.title}</h3>
                        <div style={{ fontSize: 13, color: '#64748b' }}>NT$ {p.price} · {p.date} · 瀏覽 {p.views} 次</div>
                      </div>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button style={{ padding: '7px 12px', borderRadius: 8, border: '1px solid #e2e8f0', background: '#fff', cursor: 'pointer', color: '#0ea5e9' }}><EditIcon /></button>
                        <button style={{ padding: '7px 12px', borderRadius: 8, border: '1px solid #fee2e2', background: '#fff', cursor: 'pointer', color: '#dc2626' }}><Trash2Icon /></button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {tab === 'favorites' && (
              favProducts.length === 0
                ? <div style={{ textAlign: 'center', padding: '48px 0', color: '#94a3b8' }}><div style={{ fontSize: 48, marginBottom: 12 }}>🤍</div><p>還沒有典藏商品</p></div>
                : <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))', gap: 14 }}>
                    {favProducts.map(p => (
                      <div key={p.id} style={{ background: '#fff', borderRadius: 14, overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,.05)' }}>
                        <img src={p.image} alt={p.title} style={{ width: '100%', height: 120, objectFit: 'cover' }} />
                        <div style={{ padding: '10px 12px' }}>
                          <p style={{ fontSize: 13, fontWeight: 600, color: '#1e293b', marginBottom: 4 }}>{p.title}</p>
                          <p style={{ fontSize: 14, fontWeight: 700, color: '#0ea5e9' }}>NT$ {p.price}</p>
                        </div>
                      </div>
                    ))}
                  </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
