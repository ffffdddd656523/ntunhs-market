import { useState } from 'react';
import { XIcon, CameraIcon } from '../components/Icons';
import ImageUploadModal from '../components/ImageUploadModal';
import { COLLEGES, PRODUCT_CATEGORIES, JOB_TYPES, COURSE_TYPES } from '../constants';

function DeptSelect({ value, onChange, style }) {
  return (
    <select value={value} onChange={onChange} style={style}>
      <option value="">請選擇科系（選填）</option>
      {COLLEGES.map(c => (
        <optgroup key={c.name} label={`── ${c.name} ──`}>
          {c.depts.map(d => <option key={d} value={d}>{d}</option>)}
        </optgroup>
      ))}
    </select>
  );
}

export default function CreatePostPage({ setPage, isLoggedIn }) {
  const [form, setForm] = useState({ type: 'product', title: '', category: '', price: '', description: '', contact: '', dept: '' });
  const [img, setImg] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = e => { e.preventDefault(); setSubmitted(true); };

  if (!isLoggedIn) return (
    <div style={{ maxWidth: 500, margin: '80px auto', textAlign: 'center', padding: '0 20px' }}>
      <div style={{ fontSize: 60, marginBottom: 16 }}>🔒</div>
      <h2 style={{ fontSize: 22, fontWeight: 800, color: '#1e293b', marginBottom: 10 }}>請先登入</h2>
      <p style={{ color: '#64748b', marginBottom: 24 }}>發布貼文需要登入帳號</p>
      <button onClick={() => setPage('login')} style={{ background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', color: '#fff', border: 'none', padding: '13px 32px', borderRadius: 12, cursor: 'pointer', fontWeight: 700, fontSize: 16, fontFamily: 'inherit' }}>立即登入</button>
    </div>
  );

  if (submitted) return (
    <div style={{ maxWidth: 500, margin: '80px auto', textAlign: 'center', padding: '0 20px' }}>
      <div style={{ fontSize: 60, marginBottom: 16 }}>🎉</div>
      <h2 style={{ fontSize: 22, fontWeight: 800, color: '#1e293b', marginBottom: 10 }}>貼文發布成功！</h2>
      <p style={{ color: '#64748b', marginBottom: 24 }}>你的貼文已成功發布，等待買家聯絡。</p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        <button onClick={() => setPage('products')} style={{ background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', color: '#fff', border: 'none', padding: '12px 24px', borderRadius: 10, cursor: 'pointer', fontWeight: 700, fontFamily: 'inherit' }}>瀏覽商品</button>
        <button onClick={() => { setForm({ type: 'product', title: '', category: '', price: '', description: '', contact: '', dept: '' }); setImg(null); setSubmitted(false); }} style={{ background: '#f1f5f9', color: '#475569', border: 'none', padding: '12px 24px', borderRadius: 10, cursor: 'pointer', fontWeight: 600, fontFamily: 'inherit' }}>再發一篇</button>
      </div>
    </div>
  );

  const catOptions = form.type === 'product' ? PRODUCT_CATEGORIES : form.type === 'job' ? JOB_TYPES : COURSE_TYPES;
  const inp = { width: '100%', padding: '11px 14px', border: '1px solid #e2e8f0', borderRadius: 10, fontSize: 14, outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit' };

  return (
    <>
      <ImageUploadModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onConfirm={url => setImg(url)}
        title="上傳商品圖片"
        aspect="4/3"
      />

      <div style={{ maxWidth: 680, margin: '0 auto', padding: '32px 20px' }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: '#1e293b', marginBottom: 6 }}>發布貼文</h1>
        <p style={{ color: '#64748b', marginBottom: 28 }}>分享你的商品、打工資訊或換課需求</p>

        <form onSubmit={handleSubmit} style={{ background: '#fff', borderRadius: 18, padding: '32px 28px', boxShadow: '0 2px 14px rgba(0,0,0,.07)' }}>

          {/* Type */}
          <div style={{ marginBottom: 22 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>貼文類型 *</label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              {[['product','🛍️ 商品販售'],['job','💼 打工資訊'],['course','🔄 換課資訊']].map(([v,l])=>(
                <button type="button" key={v} onClick={() => setForm({ ...form, type: v, category: '' })}
                  style={{ padding: '12px 0', borderRadius: 10, border: `2px solid ${form.type===v?'#0ea5e9':'#e2e8f0'}`, background: form.type===v?'#e0f2fe':'#fff', color: form.type===v?'#0284c7':'#475569', fontWeight: 600, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' }}>
                  {l}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>標題 *</label>
            <input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="請輸入標題" style={inp}/>
          </div>

          {/* Category */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>類別 *</label>
            <select required value={form.category} onChange={e=>setForm({...form,category:e.target.value})} style={inp}>
              <option value="">請選擇類別</option>
              {catOptions.map(o=><option key={o} value={o}>{o}</option>)}
            </select>
          </div>

          {/* Price */}
          {form.type === 'product' && (
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>價格（NT$）*</label>
              <input required type="number" min="0" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="請輸入價格" style={inp}/>
            </div>
          )}

          {/* Dept */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>所屬科系（選填）</label>
            <DeptSelect value={form.dept} onChange={e=>setForm({...form,dept:e.target.value})} style={inp}/>
          </div>

          {/* Description */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>詳細描述 *</label>
            <textarea required value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="請詳細描述商品狀況、成色、購買時間..." rows={5} style={{ ...inp, resize: 'vertical' }}/>
          </div>

          {/* Image Upload */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>商品圖片</label>
            {img ? (
              <div style={{ position: 'relative', borderRadius: 12, overflow: 'hidden' }}>
                <img src={img} alt="preview" style={{ width: '100%', height: 220, objectFit: 'cover', display: 'block' }}/>
                <div style={{ position: 'absolute', top: 10, right: 10, display: 'flex', gap: 8 }}>
                  <button type="button" onClick={() => setModalOpen(true)}
                    style={{ background: 'rgba(255,255,255,.9)', border: 'none', borderRadius: 8, padding: '7px 12px', cursor: 'pointer', fontWeight: 600, fontSize: 12, fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 5 }}>
                    <CameraIcon/>更換圖片
                  </button>
                  <button type="button" onClick={() => setImg(null)}
                    style={{ background: 'rgba(239,68,68,.9)', border: 'none', borderRadius: 8, padding: '7px 10px', cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center' }}>
                    <XIcon/>
                  </button>
                </div>
              </div>
            ) : (
              <button type="button" onClick={() => setModalOpen(true)}
                style={{ width: '100%', border: '2px dashed #e2e8f0', borderRadius: 12, padding: '36px 20px', background: '#fafafa', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, fontFamily: 'inherit', transition: 'border-color .15s' }}
                onMouseEnter={e=>e.currentTarget.style.borderColor='#0ea5e9'}
                onMouseLeave={e=>e.currentTarget.style.borderColor='#e2e8f0'}>
                <span style={{ color: '#94a3b8' }}><CameraIcon/></span>
                <span style={{ fontWeight: 600, color: '#1e293b', fontSize: 14 }}>點擊開啟圖片上傳視窗</span>
                <span style={{ fontSize: 12, color: '#94a3b8' }}>支援旋轉與縮放，建議比例 4:3</span>
              </button>
            )}
          </div>

          {/* Contact */}
          <div style={{ marginBottom: 24 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>聯絡方式 *</label>
            <input required value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} placeholder="例如：Email、手機、Line ID" style={inp}/>
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <button type="submit" style={{ flex: 1, background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', color: '#fff', border: 'none', padding: '13px 0', borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: 'pointer', fontFamily: 'inherit' }}>發布貼文</button>
            <button type="button" onClick={()=>setForm({type:'product',title:'',category:'',price:'',description:'',contact:'',dept:''})}
              style={{ padding: '13px 22px', borderRadius: 12, border: '1.5px solid #e2e8f0', background: '#fff', color: '#475569', cursor: 'pointer', fontWeight: 600, fontFamily: 'inherit' }}>重設</button>
          </div>
        </form>
      </div>
    </>
  );
}
