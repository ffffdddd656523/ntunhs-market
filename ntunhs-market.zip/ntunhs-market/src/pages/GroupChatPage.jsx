import { useState, useEffect, useRef } from 'react';
import { Avatar } from '../components/Common';
import { SendIcon, UsersIcon } from '../components/Icons';
import { GROUP_MSGS_INIT } from '../data';

export default function GroupChatPage() {
  const [msgs,setMsgs]=useState(GROUP_MSGS_INIT);
  const [msg,setMsg]=useState('');
  const endRef=useRef(null);
  const send=e=>{
    e.preventDefault();
    if(!msg.trim()) return;
    setMsgs(m=>[...m,{id:'g'+Date.now(),sender:'我',color:'#0ea5e9',text:msg,time:new Date().toLocaleTimeString('zh-TW',{hour:'2-digit',minute:'2-digit'}),isMe:true}]);
    setMsg('');
  };
  useEffect(()=>{if(endRef.current)endRef.current.scrollIntoView({behavior:'smooth'});},[msgs.length]);
  return (
    <div style={{maxWidth:800,margin:'0 auto',padding:'32px 20px'}}>
      <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:18}}>
        <div style={{width:42,height:42,background:'linear-gradient(135deg,#0ea5e9,#0284c7)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}><UsersIcon/></div>
        <div><h1 style={{fontSize:19,fontWeight:800,color:'#1e293b',margin:0}}>北護學生大群</h1><p style={{color:'#64748b',fontSize:12,margin:0}}>全校學生公開聊天室</p></div>
      </div>
      <div style={{background:'#fff',borderRadius:18,boxShadow:'0 2px 14px rgba(0,0,0,.07)',overflow:'hidden',display:'flex',flexDirection:'column',height:520}}>
        <div style={{flex:1,overflowY:'auto',padding:'16px',display:'flex',flexDirection:'column',gap:12}}>
          {msgs.map(m=>(
            <div key={m.id} style={{display:'flex',justifyContent:m.isMe?'flex-end':'flex-start',gap:8,alignItems:'flex-end'}}>
              {!m.isMe&&<Avatar name={m.sender} color={m.color} size={30}/>}
              <div style={{maxWidth:'60%'}}>
                {!m.isMe&&<div style={{fontSize:11,color:'#64748b',marginBottom:3,marginLeft:4}}>{m.sender}</div>}
                <div style={{padding:'10px 13px',borderRadius:m.isMe?'16px 16px 4px 16px':'16px 16px 16px 4px',background:m.isMe?'linear-gradient(135deg,#0ea5e9,#0284c7)':'#f1f5f9',color:m.isMe?'#fff':'#1e293b',fontSize:13,lineHeight:1.5}}>{m.text}</div>
                <div style={{fontSize:10,color:'#94a3b8',marginTop:3,textAlign:m.isMe?'right':'left'}}>{m.time}</div>
              </div>
              {m.isMe&&<Avatar name={m.sender} color={m.color} size={30}/>}
            </div>
          ))}
          <div ref={endRef}/>
        </div>
        <form onSubmit={send} style={{padding:'12px 16px',borderTop:'1px solid #f1f5f9',display:'flex',gap:8}}>
          <input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="輸入訊息，與全校同學交流..." style={{flex:1,padding:'10px 12px',border:'1px solid #e2e8f0',borderRadius:10,fontSize:13,outline:'none',fontFamily:'inherit'}}/>
          <button type="submit" style={{background:'linear-gradient(135deg,#0ea5e9,#0284c7)',color:'#fff',border:'none',padding:'0 18px',borderRadius:10,cursor:'pointer',display:'flex',alignItems:'center',gap:5,fontWeight:600,fontFamily:'inherit',fontSize:13}}><SendIcon/>傳送</button>
        </form>
      </div>
    </div>
  );
}
