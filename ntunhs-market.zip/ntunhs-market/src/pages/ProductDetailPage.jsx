import { CategoryBadge, Avatar } from '../components/Common';
import { HeartIcon, MessageCircleIcon, MailIcon } from '../components/Icons';

export default function ProductDetailPage({ product, favorites, toggleFav, setPage, onContact }) {
  if(!product) return null;
  const isFav=favorites.has(product.id);
  return (
    <div style={{maxWidth:1100,margin:'0 auto',padding:'32px 20px'}}>
      <div style={{fontSize:13,color:'#64748b',marginBottom:18}}>
        <button onClick={()=>setPage('home')} style={{border:'none',background:'none',color:'#64748b',cursor:'pointer',padding:0,fontFamily:'inherit'}}>首頁</button>
        <span style={{margin:'0 8px'}}>/</span>
        <button onClick={()=>setPage('products')} style={{border:'none',background:'none',color:'#64748b',cursor:'pointer',padding:0,fontFamily:'inherit'}}>商品分類</button>
        <span style={{margin:'0 8px'}}>/</span>
        <span style={{color:'#1e293b'}}>{product.title}</span>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:24}}>
        <div>
          <div style={{borderRadius:16,overflow:'hidden',background:'#f1f5f9',marginBottom:22}}>
            <img src={product.image} alt={product.title} style={{width:'100%',aspectRatio:'4/3',objectFit:'cover',display:'block'}}/>
          </div>
          <div style={{background:'#fff',borderRadius:18,padding:'26px',boxShadow:'0 2px 12px rgba(0,0,0,.06)'}}>
            <div style={{marginBottom:12}}><CategoryBadge cat={product.category}/></div>
            <h1 style={{fontSize:24,fontWeight:800,color:'#1e293b',marginBottom:8}}>{product.title}</h1>
            <div style={{fontSize:26,fontWeight:800,color:'#0ea5e9',marginBottom:14}}>NT$ {product.price}</div>
            <div style={{display:'flex',gap:16,fontSize:13,color:'#64748b',paddingBottom:16,borderBottom:'1px solid #f1f5f9',marginBottom:16}}>
              <span>賣家：{product.seller}</span>
              <span>科系：{product.dept}</span>
              <span>{product.date}</span>
            </div>
            <h2 style={{fontSize:16,fontWeight:700,color:'#1e293b',marginBottom:8}}>商品描述</h2>
            <p style={{color:'#475569',lineHeight:1.9}}>{product.description}</p>
            <div style={{display:'flex',gap:10,marginTop:24}}>
              <button onClick={()=>onContact()} style={{flex:1,background:'linear-gradient(135deg,#0ea5e9,#0284c7)',color:'#fff',border:'none',padding:'12px 0',borderRadius:12,fontWeight:700,fontSize:14,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:8,fontFamily:'inherit'}}>
                <MessageCircleIcon/>聯絡賣家
              </button>
              <button onClick={()=>toggleFav(product.id)} style={{padding:'12px 20px',borderRadius:12,border:`2px solid ${isFav?'#ef4444':'#e2e8f0'}`,background:isFav?'#fef2f2':'#fff',color:isFav?'#ef4444':'#475569',cursor:'pointer',fontWeight:600,display:'flex',alignItems:'center',gap:5,fontFamily:'inherit'}}>
                <HeartIcon filled={isFav}/>{isFav?'已收藏':'加入典藏'}
              </button>
            </div>
          </div>
        </div>
        <aside>
          <div style={{background:'#fff',borderRadius:18,padding:'22px',boxShadow:'0 2px 12px rgba(0,0,0,.06)',position:'sticky',top:80}}>
            <h3 style={{fontSize:15,fontWeight:700,color:'#1e293b',marginBottom:14}}>賣家資訊</h3>
            <div style={{display:'flex',alignItems:'center',gap:10,paddingBottom:14,borderBottom:'1px solid #f1f5f9',marginBottom:14}}>
              <Avatar name={product.seller} color="#0ea5e9" size={50}/>
              <div>
                <div style={{fontWeight:700,color:'#1e293b',fontSize:15}}>{product.seller}</div>
                <div style={{fontSize:12,color:'#64748b',marginTop:2}}>{product.dept}</div>
              </div>
            </div>
            <button onClick={()=>onContact()} style={{width:'100%',marginTop:4,background:'linear-gradient(135deg,#0ea5e9,#0284c7)',color:'#fff',border:'none',padding:'10px 0',borderRadius:10,cursor:'pointer',fontWeight:600,display:'flex',alignItems:'center',justifyContent:'center',gap:6,fontFamily:'inherit',fontSize:14}}>
              <MessageCircleIcon/>開始聊天
            </button>
            <div style={{marginTop:14,background:'#fffbeb',borderRadius:10,padding:'12px 14px'}}>
              <div style={{fontSize:13,fontWeight:700,color:'#b45309',marginBottom:6}}>交易安全提醒</div>
              <ul style={{fontSize:12,color:'#92400e',paddingLeft:16,lineHeight:1.9}}>
                <li>建議面交驗貨</li><li>使用校園安全地點</li><li>確認商品無誤再付款</li>
              </ul>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
