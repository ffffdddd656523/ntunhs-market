import { useState, useRef } from 'react';
import { XIcon, UploadIcon, RotateIcon, CheckIcon, ZoomInIcon } from './Icons';

/**
 * ImageUploadModal
 * Props:
 *   isOpen     – boolean
 *   onClose    – () => void
 *   onConfirm  – (dataUrl: string) => void
 *   title      – string  (optional label)
 *   aspect     – '4/3' | '1/1' | 'free'  (display hint only)
 */
export default function ImageUploadModal({ isOpen, onClose, onConfirm, title = '上傳圖片', aspect = '4/3' }) {
  const [preview, setPreview] = useState(null);
  const [rotation, setRotation] = useState(0);
  const [scale, setScale] = useState(1);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef(null);

  if (!isOpen) return null;

  const readFile = file => {
    if (!file || !file.type.startsWith('image/')) return;
    const r = new FileReader();
    r.onloadend = () => { setPreview(r.result); setRotation(0); setScale(1); };
    r.readAsDataURL(file);
  };

  const handleFile = e => readFile(e.target.files && e.target.files[0]);

  const handleDrop = e => {
    e.preventDefault(); setDragging(false);
    readFile(e.dataTransfer.files && e.dataTransfer.files[0]);
  };

  const handleConfirm = () => {
    if (!preview) return;
    // Build a transformed canvas to bake in rotation/scale
    const img = new window.Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const rad = (rotation * Math.PI) / 180;
      const cos = Math.abs(Math.cos(rad));
      const sin = Math.abs(Math.sin(rad));
      canvas.width  = (img.width * cos + img.height * sin) * scale;
      canvas.height = (img.width * sin + img.height * cos) * scale;
      const ctx = canvas.getContext('2d');
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(rad);
      ctx.scale(scale, scale);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      onConfirm(canvas.toDataURL('image/jpeg', 0.9));
      handleClose();
    };
    img.src = preview;
  };

  const handleClose = () => { setPreview(null); setRotation(0); setScale(1); onClose(); };

  const btnStyle = (color = '#0ea5e9', bg = '#e0f2fe') => ({
    border: 'none', borderRadius: 8, padding: '8px 14px', cursor: 'pointer',
    background: bg, color, fontWeight: 600, fontSize: 13, fontFamily: 'inherit',
    display: 'flex', alignItems: 'center', gap: 6,
  });

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.55)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ background: '#fff', borderRadius: 20, width: '100%', maxWidth: 540, boxShadow: '0 20px 60px rgba(0,0,0,.25)', overflow: 'hidden' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 22px', borderBottom: '1px solid #f1f5f9' }}>
          <h2 style={{ fontSize: 17, fontWeight: 700, color: '#1e293b', margin: 0 }}>{title}</h2>
          <button onClick={handleClose} style={{ border: 'none', background: '#f1f5f9', borderRadius: 8, cursor: 'pointer', padding: '6px 8px', display: 'flex', alignItems: 'center' }}><XIcon /></button>
        </div>

        <div style={{ padding: '20px 22px' }}>
          {/* Drop zone / preview */}
          {!preview ? (
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => inputRef.current && inputRef.current.click()}
              style={{ border: `2px dashed ${dragging ? '#0ea5e9' : '#e2e8f0'}`, borderRadius: 14, padding: '48px 20px', textAlign: 'center', cursor: 'pointer', background: dragging ? '#f0f9ff' : '#fafafa', transition: 'all .15s' }}
            >
              <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} style={{ display: 'none' }} />
              <div style={{ color: '#94a3b8', margin: '0 auto 12px', width: 48, height: 48 }}><UploadIcon /></div>
              <p style={{ fontWeight: 600, color: '#1e293b', marginBottom: 6, fontSize: 15 }}>拖曳圖片到這裡，或點擊選擇</p>
              <p style={{ fontSize: 12, color: '#94a3b8' }}>支援 JPG、PNG、WebP（最大 10 MB）</p>
              <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 4 }}>建議比例：{aspect}</p>
            </div>
          ) : (
            <>
              {/* Image preview with transform */}
              <div style={{ width: '100%', aspectRatio: '4/3', background: '#0f172a', borderRadius: 12, overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <img
                  src={preview}
                  alt="preview"
                  style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', transform: `rotate(${rotation}deg) scale(${scale})`, transition: 'transform .2s' }}
                />
              </div>

              {/* Controls */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 16, alignItems: 'center' }}>
                <button style={btnStyle('#475569', '#f1f5f9')} onClick={() => setRotation(r => r - 90)}>
                  <RotateIcon />向左旋轉
                </button>
                <button style={btnStyle('#475569', '#f1f5f9')} onClick={() => setRotation(r => r + 90)}>
                  <RotateIcon />向右旋轉
                </button>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 160 }}>
                  <ZoomInIcon />
                  <input
                    type="range" min="0.5" max="2" step="0.05"
                    value={scale} onChange={e => setScale(+e.target.value)}
                    style={{ flex: 1, accentColor: '#0ea5e9' }}
                  />
                  <span style={{ fontSize: 12, color: '#64748b', minWidth: 36 }}>{Math.round(scale * 100)}%</span>
                </div>
              </div>

              {/* Re-upload */}
              <button onClick={() => inputRef.current && inputRef.current.click()} style={{ ...btnStyle('#64748b', '#f8fafc'), border: '1px solid #e2e8f0', marginBottom: 4, fontSize: 12 }}>
                <UploadIcon />重新選擇圖片
              </button>
              <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} style={{ display: 'none' }} />
            </>
          )}
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', gap: 10, padding: '14px 22px', borderTop: '1px solid #f1f5f9', justifyContent: 'flex-end' }}>
          <button onClick={handleClose} style={{ border: '1px solid #e2e8f0', background: '#fff', borderRadius: 10, padding: '10px 20px', cursor: 'pointer', fontWeight: 600, fontSize: 14, color: '#475569', fontFamily: 'inherit' }}>
            取消
          </button>
          <button
            onClick={handleConfirm}
            disabled={!preview}
            style={{ background: preview ? 'linear-gradient(135deg,#0ea5e9,#0284c7)' : '#cbd5e1', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 24px', cursor: preview ? 'pointer' : 'not-allowed', fontWeight: 700, fontSize: 14, display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'inherit' }}
          >
            <CheckIcon />確認使用
          </button>
        </div>
      </div>
    </div>
  );
}
