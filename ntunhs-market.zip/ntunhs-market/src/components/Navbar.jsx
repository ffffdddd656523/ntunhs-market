import { useState } from 'react';
import { UserIcon, LogInIcon, MenuIcon, XIcon, PresentationIcon } from './Icons';

export default function Navbar({ page, setPage, isLoggedIn }) {
  const [open, setOpen] = useState(false);
  const links = [
    { id: 'home', label: '首頁' },
    { id: 'products', label: '商品分類' },
    { id: 'jobs', label: '打工資訊' },
    { id: 'courses', label: '換課資訊' },
    { id: 'create', label: '發布貼文' },
    { id: 'group-chat', label: '北護大群' },
    { id: 'presentation', label: '📋 成果報表', special: true },
  ];
  const go = p => { setPage(p); setOpen(false); };
  const btn = active => ({
    border: 'none', background: 'none', cursor: 'pointer', padding: '6px 9px', borderRadius: 8,
    color: active ? '#0ea5e9' : '#475569', fontWeight: active ? 700 : 500, fontSize: 13, fontFamily: 'inherit',
  });
  return (
    <nav style={{ background: '#fff', boxShadow: '0 1px 8px rgba(0,0,0,.06)', position: 'sticky', top: 0, zIndex: 100 }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
        <button onClick={() => go('home')} style={{ display: 'flex', alignItems: 'center', gap: 10, border: 'none', background: 'none', cursor: 'pointer' }}>
          <div style={{ width: 40, height: 40, background: 'linear-gradient(135deg,#0ea5e9,#0284c7)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ color: '#fff', fontSize: 18, fontWeight: 700 }}>北</span>
          </div>
          <span style={{ fontSize: 15, fontWeight: 700, color: '#1e293b' }}>北護小物販賣</span>
        </button>

        {/* Desktop */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'nowrap' }}>
          {links.map(l => (
            <button key={l.id} style={{ ...btn(page === l.id), ...(l.special ? { background: '#fef3c7', color: '#92400e', fontWeight: 700, borderRadius: 8 } : {}) }} onClick={() => go(l.id)}>
              {l.label}
            </button>
          ))}
          {isLoggedIn
            ? <button onClick={() => go('profile')} style={{ ...btn(page === 'profile'), display: 'flex', alignItems: 'center', gap: 5, color: '#0ea5e9', fontWeight: 600 }}><UserIcon />會員中心</button>
            : <button onClick={() => go('login')} style={{ display: 'flex', alignItems: 'center', gap: 6, background: '#0ea5e9', color: '#fff', border: 'none', cursor: 'pointer', padding: '8px 14px', borderRadius: 8, fontWeight: 600, fontSize: 13, fontFamily: 'inherit', marginLeft: 4 }}><LogInIcon />登入</button>
          }
        </div>

        {/* Mobile toggle */}
        <button onClick={() => setOpen(v => !v)} style={{ display: 'none', border: 'none', background: 'none', cursor: 'pointer' }} className="mob-btn">
          {open ? <XIcon /> : <MenuIcon />}
        </button>
      </div>

      {open && (
        <div style={{ background: '#fff', borderTop: '1px solid #f1f5f9', padding: '8px 20px 16px' }}>
          {links.map(l => (
            <button key={l.id} onClick={() => go(l.id)} style={{ display: 'block', width: '100%', textAlign: 'left', border: 'none', background: 'none', padding: '10px 0', color: page === l.id ? '#0ea5e9' : '#475569', fontWeight: 600, fontFamily: 'inherit', fontSize: 14, cursor: 'pointer' }}>
              {l.label}
            </button>
          ))}
          {isLoggedIn
            ? <button onClick={() => go('profile')} style={{ display: 'block', width: '100%', textAlign: 'left', border: 'none', background: 'none', padding: '10px 0', color: '#0ea5e9', fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>會員中心</button>
            : <button onClick={() => go('login')} style={{ display: 'block', width: '100%', marginTop: 8, background: '#0ea5e9', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: 8, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>登入</button>
          }
        </div>
      )}
    </nav>
  );
}
